FolderRoot = "~/SimilaritiesMultiLabel"
FolderScripts = paste(FolderRoot, "/R", sep="")

library(progress)
library(tidyverse)
library(dplyr)
library(parallel)
library(doParallel)